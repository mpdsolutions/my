const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: { "Content-Type":"application/json", "Cache-Control":"no-store" }
});
function toHex(buffer) {
  return [...new Uint8Array(buffer)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
export async function onRequestPost({ request, env }) {
  try {
    if (!env.RAZORPAY_KEY_SECRET || !env.DB) return json({error:"Payment verification is not configured."},503);
    const body = await request.json();
    const {razorpay_order_id: orderId, razorpay_payment_id: paymentId, razorpay_signature: signature} = body;
    if (![orderId,paymentId,signature].every(v=>typeof v==="string" && v.length>5 && v.length<200)) return json({error:"Invalid payment response."},400);
    // Look up the order created by our server; do not trust a client-supplied amount/order mapping.
    const order = await env.DB.prepare("SELECT order_id, status FROM orders WHERE order_id = ?").bind(orderId).first();
    if (!order) return json({error:"Order not found."},404);
    if (order.status === "paid") return json({verified:true,alreadyVerified:true});
    const key = await crypto.subtle.importKey("raw",new TextEncoder().encode(env.RAZORPAY_KEY_SECRET),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
    const digest = await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(`${orderId}|${paymentId}`));
    const expected = toHex(digest);
    if (expected.length !== signature.length) return json({verified:false,error:"Payment signature did not match."},400);
    let diff=0; for(let i=0;i<expected.length;i++) diff |= expected.charCodeAt(i)^signature.charCodeAt(i);
    if (diff !== 0) return json({verified:false,error:"Payment signature did not match."},400);
    await env.DB.prepare("UPDATE orders SET status='signature_verified', payment_id=?, verified_at=? WHERE order_id=?")
      .bind(paymentId,new Date().toISOString(),orderId).run();
    // Signature verification authenticates the callback. For fulfilment, also confirm captured status via API/webhook.
    return json({verified:true,orderId,paymentId,message:"Signature verified. Confirm captured status before dispatch."});
  } catch (e) {
    return json({error:"Could not verify payment."},500);
  }
}
