const CATALOG = {
  1: { name: "Wireless Bluetooth Headphones", price: 1499 },
  2: { name: "Smart Fitness Watch", price: 2199 },
  3: { name: "Everyday Running Shoes", price: 1799 },
  4: { name: "Classic Travel Backpack", price: 999 },
  5: { name: "Minimal Desk Lamp", price: 799 },
  6: { name: "Insulated Water Bottle", price: 499 },
  7: { name: "Daily Skincare Set", price: 899 },
  8: { name: "Yoga & Fitness Mat", price: 699 }
};
const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: { "Content-Type":"application/json", "Cache-Control":"no-store" }
});
export async function onRequestPost({ request, env }) {
  try {
    if (!env.RAZORPAY_KEY_ID || !env.RAZORPAY_KEY_SECRET) return json({error:"Razorpay keys are not configured in Cloudflare."},503);
    if (!env.DB) return json({error:"D1 database binding DB is missing."},503);
    const body = await request.json();
    const c = body.customer || {};
    if (!c.name || !c.email || !/^[0-9]{10}$/.test(c.phone || "") || !c.address) return json({error:"Please provide valid delivery details."},400);
    if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 20) return json({error:"Invalid cart."},400);
    let total = 0;
    const cleanItems = [];
    for (const item of body.items) {
      const product = CATALOG[Number(item.id)];
      const quantity = Number(item.quantity);
      if (!product || !Number.isInteger(quantity) || quantity < 1 || quantity > 10) return json({error:"Invalid product or quantity."},400);
      total += product.price * quantity;
      cleanItems.push({id:Number(item.id), quantity, name:product.name, price:product.price});
    }
    if (total < 1 || total > 500000) return json({error:"Order amount is outside allowed limits."},400);
    const receipt = "npd_" + crypto.randomUUID().replaceAll("-","").slice(0,20);
    const auth = btoa(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`);
    const rp = await fetch("https://api.razorpay.com/v1/orders", {
      method:"POST", headers:{"Authorization":`Basic ${auth}`,"Content-Type":"application/json"},
      body:JSON.stringify({amount:total*100,currency:"INR",receipt,notes:{store:"NPD Card"}})
    });
    const order = await rp.json();
    if (!rp.ok) return json({error:order.error?.description || "Razorpay order creation failed."},502);
    await env.DB.prepare("INSERT INTO orders (order_id, amount_paise, currency, customer_name, customer_email, customer_phone, delivery_address, items_json, status, created_at) VALUES (?, ?, 'INR', ?, ?, ?, ?, ?, 'created', ?)")
      .bind(order.id,total*100,String(c.name).slice(0,80),String(c.email).slice(0,120),String(c.phone),String(c.address).slice(0,250),JSON.stringify(cleanItems),new Date().toISOString()).run();
    return json({orderId:order.id,amount:order.amount,currency:order.currency,keyId:env.RAZORPAY_KEY_ID});
  } catch (e) {
    return json({error:"Could not create order. Check Cloudflare configuration."},500);
  }
}
