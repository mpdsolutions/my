# NPD Card — Cloudflare Pages + Razorpay starter

## What is included
- Responsive shopping storefront, category filters, product search and browser cart.
- Cloudflare Pages Functions API for Razorpay order creation and signature verification.
- D1 schema to record order and payment verification status.
- Razorpay Checkout uses a server-created order. Product prices are checked on the server.

## Deploy

1. Extract the ZIP. Upload all files/folders to a GitHub repository. Keep `index.html`, `functions/`, `migrations/` and `wrangler.toml` at repository root.
2. Cloudflare Dashboard → Workers & Pages → Create application → Pages → Connect to Git → choose repository.
3. Framework preset: None. Build command: leave empty. Build output directory: `.`. Deploy.
4. In Cloudflare, create a D1 database named `npd-card-db` (Workers & Pages → D1 / Storage & databases → D1).
5. Apply `migrations/0001_init.sql` to the new D1 database using the D1 console, or run `wrangler d1 migrations apply npd-card-db --remote` from Wrangler after setting up the project.
6. Copy the D1 database ID into `wrangler.toml` in place of `REPLACE_WITH_YOUR_D1_DATABASE_ID`, commit and push.
7. In Pages project → Settings → Functions → D1 database bindings, add binding name `DB` and select `npd-card-db`. Save and redeploy.
8. In Pages project → Settings → Variables and Secrets, add these as **Secrets** (not plain text):
   - `RAZORPAY_KEY_ID` = your Razorpay Key ID
   - `RAZORPAY_KEY_SECRET` = your Razorpay Key Secret
   Use Razorpay Test Mode keys first. Never put the Key Secret in frontend code, GitHub, chat, or `wrangler.toml`.
9. Redeploy. Test a complete payment using Razorpay test mode. Only after testing, switch to Live Mode keys in Cloudflare Secrets and follow Razorpay's activation/KYC requirements.

## Important production notes
- This is a starter integration, not a fully production-ready marketplace. It does not yet implement user accounts, admin authentication, stock reservation, shipping/tax rules, refund handling, webhook processing, or a complete order-management dashboard.
- The API stores orders and verifies the checkout signature. A verified signature is not by itself proof that funds are captured; confirm payment/order status with Razorpay API or implement signed webhooks (`payment.captured`, `order.paid`) before shipping goods.
- Customer data is stored in D1. Add privacy policy, terms, retention controls, rate limiting/abuse protection, and operational monitoring before public launch.
- Sample catalogue/prices are placeholders. Update both `app.js` display data and the server-side `CATALOG` in `functions/api/create-order.js` together.
- This project uses Razorpay Standard Checkout. See official docs: https://razorpay.com/docs/payments/payment-gateway/web-integration/standard/

## Local preview
A static local file preview can show the storefront, but API payment endpoints require Cloudflare Pages Functions, D1 and configured secrets. Deploy to a Cloudflare preview URL to test the complete flow.
