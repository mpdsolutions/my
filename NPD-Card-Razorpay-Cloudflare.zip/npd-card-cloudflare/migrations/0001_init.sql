CREATE TABLE IF NOT EXISTS orders (
  order_id TEXT PRIMARY KEY,
  amount_paise INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'INR',
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  delivery_address TEXT NOT NULL,
  items_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'created',
  payment_id TEXT,
  created_at TEXT NOT NULL,
  verified_at TEXT
);
